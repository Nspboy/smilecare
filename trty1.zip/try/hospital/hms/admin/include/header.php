<div class="container-fluid sticky-top bg-white shadow-sm">
        <div class="container">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0">
                <a href="index.html" class="navbar-brand">
                    <h1 class="m-0 text-uppercase text-primary"></i>SmileCare</h1>
                    <!--<i class="fa fa-clinic-medical me-2"> -->
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse"> 
                    <div class="navbar-nav ms-auto py-0">

                        <a href="#home" class="nav-item nav-link active">Home</a>
                        <a href="#about" class="nav-item nav-link">About</a>
                        <a href="#service" class="nav-item nav-link">Service</a>
                        <a href="hms/user-login.php" class="nav-item nav-link">Appointment</a>


                      
                      

                       
                        <!-- <a href="#satus" class="nav-item nav-link">Status</a> -->
                        <!-- <a href="#service" class="nav-item nav-link">appoointment</a> -->
                        <!-- <a class="btn btn-dark rounded-pill py-3 px-5 me-3" href="">Find Doctor</a> -->



                        <!-- <a href="#contact" class="nav-item nav-link">Contact</a>  -->
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Login</a>
                            <div class="dropdown-menu m-0">
                                <a href="hms/admin" class="dropdown-item">Admin</a>
                                <a href="hms/doctor" class="dropdown-item">Doctor</a>
                                <a href="hms/user-login.php" class="dropdown-item">Patient</a>
                               
                            </div>
                            
                            <!-- <button class="btn btn-primary w-100 py-0" type="submit"> Appointment</button> -->



                           



                        
                        
                    </div>

                    </div> 
                </div>
            </nav>
        </div>
    </div>


  